
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const Careers = () => {
  const positions = [
    {
      title: "Senior Frontend Engineer",
      department: "Engineering",
      location: "Remote",
      type: "Full-time",
    },
    {
      title: "AI/ML Engineer",
      department: "Engineering",
      location: "Remote",
      type: "Full-time",
    },
    {
      title: "Product Designer",
      department: "Design",
      location: "Remote",
      type: "Full-time",
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <h1 className="text-5xl font-bold text-center mb-8">Join Our Team</h1>
          <p className="text-xl text-neutral text-center mb-16 max-w-3xl mx-auto">
            Help us shape the future of web development. We're always looking for talented individuals to join our team.
          </p>

          <div className="space-y-6">
            {positions.map((position, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl shadow-sm p-6 hover:shadow-md transition-shadow"
              >
                <h3 className="text-2xl font-bold mb-2">{position.title}</h3>
                <div className="flex flex-wrap gap-4 text-sm">
                  <span className="bg-primary/10 text-primary px-3 py-1 rounded-full">
                    {position.department}
                  </span>
                  <span className="bg-neutral-100 px-3 py-1 rounded-full">
                    {position.location}
                  </span>
                  <span className="bg-neutral-100 px-3 py-1 rounded-full">
                    {position.type}
                  </span>
                </div>
                <button className="mt-4 px-6 py-2 rounded-full bg-primary text-white hover:bg-primary-light transition-colors">
                  Apply Now
                </button>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Careers;
