
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ScrollText, CheckCircle, AlertCircle } from "lucide-react";

const Terms = () => {
  const sections = [
    {
      icon: <ScrollText className="w-8 h-8" />,
      title: "Service Terms",
      content: "By using Lovable, you agree to these terms and conditions. Our service is provided 'as is' and we reserve the right to modify these terms at any time.",
    },
    {
      icon: <CheckCircle className="w-8 h-8" />,
      title: "User Responsibilities",
      content: "You are responsible for maintaining the security of your account and ensuring that any content you create complies with applicable laws and regulations.",
    },
    {
      icon: <AlertCircle className="w-8 h-8" />,
      title: "Limitations",
      content: "While we strive to provide reliable service, we cannot guarantee uninterrupted access. We are not liable for any damages arising from service interruptions.",
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <h1 className="text-5xl font-bold text-center mb-8">Terms of Service</h1>
          <p className="text-xl text-neutral text-center mb-16 max-w-3xl mx-auto">
            Please read these terms carefully before using our service.
          </p>

          <div className="max-w-4xl mx-auto space-y-12">
            {sections.map((section, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-sm p-8">
                <div className="flex items-start gap-6">
                  <div className="text-primary">{section.icon}</div>
                  <div>
                    <h3 className="text-2xl font-bold mb-4">{section.title}</h3>
                    <p className="text-neutral">{section.content}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 max-w-4xl mx-auto prose prose-neutral">
            <h2>Agreement to Terms</h2>
            <p>By accessing or using the Lovable service, you agree to be bound by these Terms. If you disagree with any part of the terms, you may not access the service.</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Terms;
