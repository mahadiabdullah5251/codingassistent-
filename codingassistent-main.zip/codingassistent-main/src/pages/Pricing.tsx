
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const Pricing = () => {
  const plans = [
    {
      name: "Hobby",
      price: "Free",
      description: "Perfect for personal projects and learning",
      features: [
        "500 AI queries per month",
        "Real-time preview",
        "Basic components",
        "Community support",
      ],
    },
    {
      name: "Pro",
      price: "$19/mo",
      description: "Ideal for freelancers and small teams",
      features: [
        "5,000 AI queries per month",
        "Priority support",
        "Advanced components",
        "Custom styling",
      ],
    },
    {
      name: "Enterprise",
      price: "Custom",
      description: "For large teams and organizations",
      features: [
        "Unlimited AI queries",
        "Dedicated support",
        "Custom features",
        "SLA guarantee",
      ],
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <h1 className="text-5xl font-bold text-center mb-8 animate-fade-in">Pricing Plans</h1>
          <p className="text-xl text-neutral text-center mb-16 max-w-3xl mx-auto animate-fade-in">
            Choose the perfect plan for your needs. All plans include core features.
          </p>
          <div className="grid md:grid-cols-3 gap-8 animate-fade-in">
            {plans.map((plan, index) => (
              <div
                key={index}
                className="p-8 rounded-2xl bg-white shadow-sm hover-scale"
              >
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <div className="text-3xl font-bold text-primary mb-4">{plan.price}</div>
                <p className="text-neutral mb-6">{plan.description}</p>
                <ul className="space-y-4">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center">
                      <span className="text-primary mr-2">✓</span>
                      {feature}
                    </li>
                  ))}
                </ul>
                <button className="w-full mt-8 px-6 py-3 rounded-full bg-primary text-white hover:bg-primary-light transition-colors">
                  Get Started
                </button>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Pricing;
