
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const Blog = () => {
  const posts = [
    {
      title: "The Future of AI in Web Development",
      date: "March 15, 2024",
      excerpt: "Exploring how artificial intelligence is transforming the way we build websites and applications.",
      category: "Technology",
    },
    {
      title: "Building Better User Experiences with AI",
      date: "March 10, 2024",
      excerpt: "Learn how AI can help create more intuitive and engaging user interfaces.",
      category: "Design",
    },
    {
      title: "Getting Started with Lovable",
      date: "March 5, 2024",
      excerpt: "A comprehensive guide to building your first project with Lovable's AI-powered platform.",
      category: "Tutorial",
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <h1 className="text-5xl font-bold text-center mb-8">Blog</h1>
          <p className="text-xl text-neutral text-center mb-16 max-w-3xl mx-auto">
            Insights, tutorials, and updates from the Lovable team
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.map((post, index) => (
              <article
                key={index}
                className="bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow p-6"
              >
                <div className="text-sm text-primary mb-2">{post.category}</div>
                <h2 className="text-2xl font-bold mb-3">{post.title}</h2>
                <p className="text-neutral mb-4">{post.excerpt}</p>
                <div className="text-sm text-neutral-light">{post.date}</div>
              </article>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Blog;
