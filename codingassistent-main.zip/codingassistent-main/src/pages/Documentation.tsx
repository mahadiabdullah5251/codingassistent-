
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Link } from "react-router-dom";

const Documentation = () => {
  const docs = [
    {
      title: "Getting Started",
      sections: [
        { title: "Quick Start Guide", path: "/docs/quick-start" },
        { title: "Installation", path: "/docs/installation" },
        { title: "Basic Concepts", path: "/docs/basic-concepts" },
      ],
    },
    {
      title: "Core Features",
      sections: [
        { title: "Code Generation", path: "/docs/code-generation" },
        { title: "Real-time Preview", path: "/docs/real-time-preview" },
        { title: "AI Commands", path: "/docs/ai-commands" },
      ],
    },
    {
      title: "Advanced Topics",
      sections: [
        { title: "Custom Components", path: "/docs/custom-components" },
        { title: "State Management", path: "/docs/state-management" },
        { title: "API Integration", path: "/docs/api-integration" },
      ],
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <h1 className="text-5xl font-bold text-center mb-8 animate-fade-in">Documentation</h1>
          <p className="text-xl text-neutral text-center mb-16 max-w-3xl mx-auto animate-fade-in">
            Learn how to use Lovable effectively with our comprehensive documentation.
          </p>
          <div className="grid md:grid-cols-3 gap-8 animate-fade-in">
            {docs.map((section, index) => (
              <div
                key={index}
                className="p-8 rounded-2xl bg-white shadow-sm hover:shadow-md transition-shadow"
              >
                <h3 className="text-2xl font-bold mb-6">{section.title}</h3>
                <ul className="space-y-4">
                  {section.sections.map((item, idx) => (
                    <li key={idx}>
                      <Link
                        to={item.path}
                        className="text-neutral hover:text-primary transition-colors"
                      >
                        {item.title}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Documentation;
