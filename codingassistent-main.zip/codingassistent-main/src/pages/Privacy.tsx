
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Shield, Lock, FileText } from "lucide-react";

const Privacy = () => {
  const sections = [
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Data Collection",
      content: "We collect minimal data necessary to provide our services. This includes basic account information, usage statistics, and project data that you explicitly create or modify.",
    },
    {
      icon: <Lock className="w-8 h-8" />,
      title: "Data Protection",
      content: "Your data is encrypted both in transit and at rest. We use industry-standard security measures to protect your information from unauthorized access.",
    },
    {
      icon: <FileText className="w-8 h-8" />,
      title: "Your Rights",
      content: "You have the right to access, modify, or delete your personal data at any time. Contact our support team to exercise these rights.",
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <h1 className="text-5xl font-bold text-center mb-8">Privacy Policy</h1>
          <p className="text-xl text-neutral text-center mb-16 max-w-3xl mx-auto">
            We take your privacy seriously. Learn about how we collect, use, and protect your data.
          </p>

          <div className="max-w-4xl mx-auto space-y-12">
            {sections.map((section, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-sm p-8">
                <div className="flex items-start gap-6">
                  <div className="text-primary">{section.icon}</div>
                  <div>
                    <h3 className="text-2xl font-bold mb-4">{section.title}</h3>
                    <p className="text-neutral">{section.content}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 max-w-4xl mx-auto prose prose-neutral">
            <h2>Last Updated: March 15, 2024</h2>
            <p>This privacy policy sets out how Lovable uses and protects any information that you provide when using our service.</p>
            <p>Lovable is committed to ensuring that your privacy is protected. Any information we ask you to provide will only be used in accordance with this privacy statement.</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Privacy;
