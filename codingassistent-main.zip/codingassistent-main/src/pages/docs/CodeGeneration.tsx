
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const CodeGeneration = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <Link to="/docs" className="inline-flex items-center text-neutral hover:text-primary mb-8">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Documentation
          </Link>
          
          <h1 className="text-4xl font-bold mb-8">Code Generation</h1>
          
          <div className="prose prose-neutral max-w-4xl">
            <h2>AI-Powered Code Generation</h2>
            <p>
              Lovable's AI can generate high-quality, production-ready code based on natural language descriptions. Learn how to effectively use this powerful feature.
            </p>

            <h3>How It Works</h3>
            <ul>
              <li>Natural language processing</li>
              <li>Context-aware code generation</li>
              <li>Best practices implementation</li>
              <li>Type-safe code generation</li>
            </ul>

            <h3>Best Practices</h3>
            <p>
              Learn how to write effective prompts that generate exactly the code you need. Our AI understands context and can generate complex components and functionality.
            </p>

            <h3>Code Quality</h3>
            <p>
              All generated code follows modern best practices, including:
            </p>
            <ul>
              <li>TypeScript type safety</li>
              <li>React hooks guidelines</li>
              <li>Accessibility standards</li>
              <li>Performance optimizations</li>
            </ul>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default CodeGeneration;
