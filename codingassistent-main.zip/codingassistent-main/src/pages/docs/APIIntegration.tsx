
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const APIIntegration = () => {
  const topics = [
    {
      title: "REST APIs",
      description: "Learn how to integrate RESTful APIs using React Query and fetch.",
    },
    {
      title: "GraphQL",
      description: "Implement GraphQL queries and mutations in your application.",
    },
    {
      title: "Authentication",
      description: "Secure your API endpoints and manage user authentication.",
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <Link to="/docs" className="inline-flex items-center text-neutral hover:text-primary mb-8">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Documentation
          </Link>
          
          <h1 className="text-4xl font-bold mb-8">API Integration</h1>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {topics.map((topic, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-sm">
                <h3 className="text-xl font-bold mb-3">{topic.title}</h3>
                <p className="text-neutral">{topic.description}</p>
              </div>
            ))}
          </div>

          <div className="prose prose-neutral max-w-4xl">
            <h2>Working with APIs</h2>
            <p>
              Learn how to integrate external APIs and build your own backend services in Lovable applications.
            </p>

            <h3>Making API Requests</h3>
            <ul>
              <li>Setting up API clients</li>
              <li>Handling authentication</li>
              <li>Error handling</li>
              <li>Request caching</li>
            </ul>

            <h3>Best Practices</h3>
            <p>
              Follow these guidelines when integrating APIs:
            </p>
            <ul>
              <li>Use environment variables for API keys</li>
              <li>Implement proper error handling</li>
              <li>Cache responses when appropriate</li>
              <li>Handle loading and error states</li>
            </ul>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default APIIntegration;
