
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const RealTimePreview = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <Link to="/docs" className="inline-flex items-center text-neutral hover:text-primary mb-8">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Documentation
          </Link>
          
          <h1 className="text-4xl font-bold mb-8">Real-Time Preview</h1>
          
          <div className="prose prose-neutral max-w-4xl">
            <h2>Live Preview Environment</h2>
            <p>
              See your changes instantly as you develop. Lovable's real-time preview feature helps you iterate faster and catch issues early.
            </p>

            <h3>Features</h3>
            <ul>
              <li>Instant visual feedback</li>
              <li>Hot module reloading</li>
              <li>Error highlighting</li>
              <li>Responsive design testing</li>
            </ul>

            <h3>Preview Modes</h3>
            <p>
              Switch between different preview modes to test your application:
            </p>
            <ul>
              <li>Desktop view</li>
              <li>Tablet view</li>
              <li>Mobile view</li>
              <li>Custom viewport sizes</li>
            </ul>

            <h3>Development Tools</h3>
            <p>
              Use the integrated developer tools to inspect elements, debug issues, and optimize performance in real-time.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default RealTimePreview;
