
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const QuickStart = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <Link to="/docs" className="inline-flex items-center text-neutral hover:text-primary mb-8">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Documentation
          </Link>
          
          <h1 className="text-4xl font-bold mb-8">Quick Start Guide</h1>
          
          <div className="prose prose-neutral max-w-4xl">
            <h2>Getting Started with Lovable</h2>
            <p>
              Welcome to Lovable! This guide will help you get up and running with your first AI-powered web development project in minutes.
            </p>

            <h3>Prerequisites</h3>
            <ul>
              <li>A modern web browser</li>
              <li>Basic understanding of web development</li>
              <li>Lovable account (free to create)</li>
            </ul>

            <h3>Create Your First Project</h3>
            <ol>
              <li>Log in to your Lovable account</li>
              <li>Click "New Project" in the dashboard</li>
              <li>Choose a template or start from scratch</li>
              <li>Give your project a name</li>
            </ol>

            <h3>Next Steps</h3>
            <p>
              Once your project is created, you can start building right away using natural language commands in the chat interface.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default QuickStart;
