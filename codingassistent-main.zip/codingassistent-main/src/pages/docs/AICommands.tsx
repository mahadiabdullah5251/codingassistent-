
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const AICommands = () => {
  const commands = [
    {
      type: "Creation",
      examples: [
        "Create a new component",
        "Add a form with validation",
        "Generate an API endpoint",
      ],
    },
    {
      type: "Modification",
      examples: [
        "Update the styling",
        "Add responsive design",
        "Implement dark mode",
      ],
    },
    {
      type: "Integration",
      examples: [
        "Connect to an API",
        "Add authentication",
        "Implement state management",
      ],
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <Link to="/docs" className="inline-flex items-center text-neutral hover:text-primary mb-8">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Documentation
          </Link>
          
          <h1 className="text-4xl font-bold mb-8">AI Commands</h1>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {commands.map((category, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-sm">
                <h3 className="text-xl font-bold mb-4">{category.type} Commands</h3>
                <ul className="space-y-2">
                  {category.examples.map((example, idx) => (
                    <li key={idx} className="text-neutral">{example}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="prose prose-neutral max-w-4xl">
            <h2>Using AI Commands</h2>
            <p>
              AI commands are natural language instructions that Lovable understands and converts into code changes. Learn how to effectively communicate with the AI to build your application.
            </p>

            <h3>Command Structure</h3>
            <p>
              While Lovable understands natural language, following certain patterns can help get better results:
            </p>
            <ul>
              <li>Be specific about what you want to achieve</li>
              <li>Mention any important constraints or requirements</li>
              <li>Reference existing components when needed</li>
              <li>Include styling preferences if relevant</li>
            </ul>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default AICommands;
