
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const Installation = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <Link to="/docs" className="inline-flex items-center text-neutral hover:text-primary mb-8">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Documentation
          </Link>
          
          <h1 className="text-4xl font-bold mb-8">Installation Guide</h1>
          
          <div className="prose prose-neutral max-w-4xl">
            <h2>Setting Up Your Development Environment</h2>
            <p>
              Lovable is a cloud-based platform, so there's no need for local installation. However, you might want to set up some tools for the best development experience.
            </p>

            <h3>Recommended Tools</h3>
            <ul>
              <li>Visual Studio Code with Lovable extension</li>
              <li>Git for version control</li>
              <li>Node.js and npm (for local development)</li>
            </ul>

            <h3>Environment Setup</h3>
            <ol>
              <li>Install the Lovable VS Code extension</li>
              <li>Configure your API keys</li>
              <li>Set up version control</li>
            </ol>

            <h3>Configuration</h3>
            <p>
              Learn about configuring your Lovable environment and setting up your preferences for the best development experience.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Installation;
