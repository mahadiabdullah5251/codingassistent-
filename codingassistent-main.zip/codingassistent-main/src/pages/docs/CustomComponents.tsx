
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const CustomComponents = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <Link to="/docs" className="inline-flex items-center text-neutral hover:text-primary mb-8">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Documentation
          </Link>
          
          <h1 className="text-4xl font-bold mb-8">Custom Components</h1>
          
          <div className="prose prose-neutral max-w-4xl">
            <h2>Building Custom Components</h2>
            <p>
              Learn how to create reusable, maintainable custom components in your Lovable projects. Follow best practices for component architecture and design.
            </p>

            <h3>Component Structure</h3>
            <ul>
              <li>Proper file organization</li>
              <li>TypeScript interfaces</li>
              <li>Props documentation</li>
              <li>Component composition</li>
            </ul>

            <h3>Best Practices</h3>
            <p>
              Follow these guidelines when creating custom components:
            </p>
            <ul>
              <li>Keep components focused and single-responsibility</li>
              <li>Use TypeScript for type safety</li>
              <li>Implement proper prop validation</li>
              <li>Write reusable styles</li>
            </ul>

            <h3>Component Library Integration</h3>
            <p>
              Learn how to integrate your custom components with existing UI libraries and maintain consistency across your application.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default CustomComponents;
