
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const BasicConcepts = () => {
  const concepts = [
    {
      title: "Projects",
      description: "A project is your workspace where you build and manage your web application. Each project has its own codebase, settings, and preview environment.",
    },
    {
      title: "AI Commands",
      description: "Natural language instructions that you can use to modify your code. Simply describe what you want to achieve, and Lovable will implement it.",
    },
    {
      title: "Live Preview",
      description: "See your changes in real-time as you modify your code. The preview updates automatically as you make changes.",
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <Link to="/docs" className="inline-flex items-center text-neutral hover:text-primary mb-8">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Documentation
          </Link>
          
          <h1 className="text-4xl font-bold mb-8">Basic Concepts</h1>
          
          <div className="space-y-8 mb-12">
            {concepts.map((concept, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-sm">
                <h3 className="text-xl font-bold mb-3">{concept.title}</h3>
                <p className="text-neutral">{concept.description}</p>
              </div>
            ))}
          </div>

          <div className="prose prose-neutral max-w-4xl">
            <h2>Understanding Lovable's Architecture</h2>
            <p>
              Lovable uses a modern tech stack including React, TypeScript, and Tailwind CSS. All projects are built with best practices and maintainability in mind.
            </p>

            <h3>Key Components</h3>
            <ul>
              <li>React-based frontend</li>
              <li>TypeScript for type safety</li>
              <li>Tailwind CSS for styling</li>
              <li>AI-powered code generation</li>
            </ul>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default BasicConcepts;
