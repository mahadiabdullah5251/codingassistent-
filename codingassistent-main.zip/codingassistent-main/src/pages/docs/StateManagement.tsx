
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const StateManagement = () => {
  const concepts = [
    {
      title: "Local State",
      description: "Managing component-level state using React's useState and useReducer hooks.",
    },
    {
      title: "Global State",
      description: "Implementing application-wide state management using React Query and context.",
    },
    {
      title: "State Persistence",
      description: "Storing and retrieving state data using local storage and cookies.",
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <Link to="/docs" className="inline-flex items-center text-neutral hover:text-primary mb-8">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Documentation
          </Link>
          
          <h1 className="text-4xl font-bold mb-8">State Management</h1>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {concepts.map((concept, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-sm">
                <h3 className="text-xl font-bold mb-3">{concept.title}</h3>
                <p className="text-neutral">{concept.description}</p>
              </div>
            ))}
          </div>

          <div className="prose prose-neutral max-w-4xl">
            <h2>Managing Application State</h2>
            <p>
              Learn about different state management approaches and when to use each one in your Lovable applications.
            </p>

            <h3>React Query</h3>
            <p>
              Lovable uses React Query for efficient server state management. Learn how to:
            </p>
            <ul>
              <li>Set up queries and mutations</li>
              <li>Handle loading and error states</li>
              <li>Implement data caching</li>
              <li>Optimize performance</li>
            </ul>

            <h3>Context API</h3>
            <p>
              Understand how to use React's Context API for sharing state between components without prop drilling.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default StateManagement;
