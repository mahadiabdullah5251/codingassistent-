
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Code, Sparkles, Zap } from "lucide-react";

const FeaturesPage = () => {
  const features = [
    {
      icon: <Code className="w-12 h-12" />,
      title: "Code Generation",
      description:
        "Generate high-quality React code instantly with natural language commands. Our AI understands your intent and creates clean, maintainable code that follows best practices.",
    },
    {
      icon: <Sparkles className="w-12 h-12" />,
      title: "Real-time Preview",
      description:
        "See your changes instantly with our live preview feature. Watch your application evolve in real-time as you describe the changes you want to make.",
    },
    {
      icon: <Zap className="w-12 h-12" />,
      title: "Quick Iterations",
      description:
        "Rapidly iterate and refine your designs with AI assistance. Make changes, test ideas, and perfect your application faster than ever before.",
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <h1 className="text-5xl font-bold text-center mb-8 animate-fade-in">Features</h1>
          <p className="text-xl text-neutral text-center mb-16 max-w-3xl mx-auto animate-fade-in">
            Discover how Lovable can transform your web development workflow with powerful AI-driven
            features.
          </p>
          <div className="grid md:grid-cols-2 gap-12 animate-fade-in">
            {features.map((feature, index) => (
              <div
                key={index}
                className="p-8 rounded-2xl bg-white shadow-sm hover-scale"
              >
                <div className="text-primary mb-6">{feature.icon}</div>
                <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
                <p className="text-neutral text-lg">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default FeaturesPage;
