
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Shield, Key, Server } from "lucide-react";

const Security = () => {
  const measures = [
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Data Encryption",
      content: "All data is encrypted in transit using TLS 1.3 and at rest using AES-256 encryption.",
    },
    {
      icon: <Key className="w-8 h-8" />,
      title: "Access Control",
      content: "We implement strict access controls and multi-factor authentication for all system access.",
    },
    {
      icon: <Server className="w-8 h-8" />,
      title: "Infrastructure Security",
      content: "Our infrastructure is monitored 24/7 and regularly undergoes security audits and penetration testing.",
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <h1 className="text-5xl font-bold text-center mb-8">Security</h1>
          <p className="text-xl text-neutral text-center mb-16 max-w-3xl mx-auto">
            Learn about the measures we take to protect your data and ensure the security of our platform.
          </p>

          <div className="max-w-4xl mx-auto space-y-12">
            {measures.map((measure, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-sm p-8">
                <div className="flex items-start gap-6">
                  <div className="text-primary">{measure.icon}</div>
                  <div>
                    <h3 className="text-2xl font-bold mb-4">{measure.title}</h3>
                    <p className="text-neutral">{measure.content}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 max-w-4xl mx-auto prose prose-neutral">
            <h2>Our Commitment to Security</h2>
            <p>Security is at the core of everything we do at Lovable. We continuously monitor and improve our security measures to protect your data and maintain your trust.</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Security;
