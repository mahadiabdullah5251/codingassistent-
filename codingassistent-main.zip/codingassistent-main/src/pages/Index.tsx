import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import Footer from "@/components/Footer";
import { TestimonialsSection } from "@/components/blocks/testimonials-with-marquee";
import { AppGenerator } from "@/components/AppGenerator";
const testimonials = [{
  author: {
    name: "Emma Thompson",
    handle: "@emmaai",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face"
  },
  text: "Using Lovable has transformed how we build web applications. The AI assistance and real-time preview are game-changers.",
  href: "https://twitter.com/emmaai"
}, {
  author: {
    name: "David Park",
    handle: "@davidtech",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
  },
  text: "The development experience is flawless. We've reduced our development time by 60% since implementing Lovable.",
  href: "https://twitter.com/davidtech"
}, {
  author: {
    name: "Sofia Rodriguez",
    handle: "@sofiaml",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=face"
  },
  text: "Finally, an AI tool that actually understands web development! The accuracy and code quality are impressive."
}];
const Index = () => {
  return <div className="min-h-screen rounded-lg">
      <Navbar />
      <Hero />
      <Features />
      <AppGenerator />
      <TestimonialsSection title="Trusted by developers worldwide" description="Join thousands of developers who are already building the future with Lovable" testimonials={testimonials} />
      <Footer />
    </div>;
};
export default Index;