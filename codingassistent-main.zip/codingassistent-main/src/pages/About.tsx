
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Users, Target, Heart } from "lucide-react";

const About = () => {
  const values = [
    {
      icon: <Users className="w-12 h-12" />,
      title: "Team First",
      description: "We believe in collaboration, transparency, and empowering our team members.",
    },
    {
      icon: <Target className="w-12 h-12" />,
      title: "Innovation Driven",
      description: "Pushing the boundaries of what's possible with AI and web development.",
    },
    {
      icon: <Heart className="w-12 h-12" />,
      title: "User Focused",
      description: "Everything we build is designed with our users' success in mind.",
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-6">
          <h1 className="text-5xl font-bold text-center mb-8">About Lovable</h1>
          <p className="text-xl text-neutral text-center mb-16 max-w-3xl mx-auto">
            We're on a mission to revolutionize web development through the power of AI, making it more accessible and efficient for everyone.
          </p>

          <div className="grid md:grid-cols-3 gap-12 mb-20">
            {values.map((value, index) => (
              <div
                key={index}
                className="p-8 rounded-2xl bg-white shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="text-primary mb-6">{value.icon}</div>
                <h3 className="text-2xl font-bold mb-4">{value.title}</h3>
                <p className="text-neutral">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default About;
