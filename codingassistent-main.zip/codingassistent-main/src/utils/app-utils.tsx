
import { AppType } from "@/types/generated-app";
import React from "react";

export const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleString();
};

export const getAppTypeIcon = (type: AppType | string): React.ReactNode => {
  switch (type) {
    case 'frontend':
      return <div className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs font-medium">Frontend</div>;
    case 'backend':
      return <div className="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-medium">Backend</div>;
    case 'fullstack':
      return <div className="bg-purple-100 text-purple-700 px-2 py-1 rounded text-xs font-medium">Fullstack</div>;
    default:
      return null;
  }
};

export const copyToClipboard = (text: string): void => {
  navigator.clipboard.writeText(text);
};

export const downloadAsFile = (content: string, filename: string): void => {
  const element = document.createElement('a');
  const file = new Blob([content], {type: 'text/plain'});
  element.href = URL.createObjectURL(file);
  element.download = filename;
  document.body.appendChild(element);
  element.click();
  document.body.removeChild(element);
};
