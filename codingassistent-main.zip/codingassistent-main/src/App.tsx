
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Features from "./pages/Features";
import Documentation from "./pages/Documentation";
import Pricing from "./pages/Pricing";
import About from "./pages/About";
import Blog from "./pages/Blog";
import Careers from "./pages/Careers";
import Contact from "./pages/Contact";
import Privacy from "./pages/Privacy";
import Terms from "./pages/Terms";
import Security from "./pages/Security";
import NotFound from "./pages/NotFound";
import QuickStart from "./pages/docs/QuickStart";
import Installation from "./pages/docs/Installation";
import BasicConcepts from "./pages/docs/BasicConcepts";
import CodeGeneration from "./pages/docs/CodeGeneration";
import RealTimePreview from "./pages/docs/RealTimePreview";
import AICommands from "./pages/docs/AICommands";
import CustomComponents from "./pages/docs/CustomComponents";
import StateManagement from "./pages/docs/StateManagement";
import APIIntegration from "./pages/docs/APIIntegration";
import Auth from "./pages/Auth";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/features" element={<Features />} />
          <Route path="/docs" element={<Documentation />} />
          <Route path="/docs/quick-start" element={<QuickStart />} />
          <Route path="/docs/installation" element={<Installation />} />
          <Route path="/docs/basic-concepts" element={<BasicConcepts />} />
          <Route path="/docs/code-generation" element={<CodeGeneration />} />
          <Route path="/docs/real-time-preview" element={<RealTimePreview />} />
          <Route path="/docs/ai-commands" element={<AICommands />} />
          <Route path="/docs/custom-components" element={<CustomComponents />} />
          <Route path="/docs/state-management" element={<StateManagement />} />
          <Route path="/docs/api-integration" element={<APIIntegration />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/about" element={<About />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/careers" element={<Careers />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/security" element={<Security />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
