
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

const Hero = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Check current user on mount
    const getUser = async () => {
      const { data } = await supabase.auth.getSession();
      setUser(data.session?.user || null);
    };
    
    getUser();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setUser(session?.user || null);
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return (
    <section className="pt-32 pb-20 px-6">
      <div className="container mx-auto text-center">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fade-in">
          Build Beautiful Apps with AI
        </h1>
        <p className="text-xl md:text-2xl text-neutral mb-12 max-w-3xl mx-auto animate-fade-in">
          Create stunning web applications using natural language. Just describe what you want to build,
          and watch your ideas come to life.
        </p>
        <div className="flex flex-col md:flex-row gap-4 justify-center items-center animate-fade-in">
          {user ? (
            <Link to="/" className="w-full md:w-auto">
              <button className="px-8 py-3 rounded-full bg-primary text-white hover:bg-primary-light transition-colors w-full">
                Continue Building
              </button>
            </Link>
          ) : (
            <Link to="/auth" className="w-full md:w-auto">
              <button className="px-8 py-3 rounded-full bg-primary text-white hover:bg-primary-light transition-colors w-full">
                Start Building Now
              </button>
            </Link>
          )}
          <button className="px-8 py-3 rounded-full border-2 border-primary text-primary hover:bg-primary/5 transition-colors w-full md:w-auto">
            Watch Demo
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;
