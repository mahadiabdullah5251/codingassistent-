
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { GeneratedApp } from "@/types/generated-app";
import { formatDate, getAppTypeIcon } from "@/utils/app-utils";

interface AppCardProps {
  app: GeneratedApp;
  isSelected: boolean;
  onClick: () => void;
}

export function AppCard({ app, isSelected, onClick }: AppCardProps) {
  return (
    <Card 
      className={`cursor-pointer hover:border-primary transition-colors ${isSelected ? 'border-primary' : ''}`}
      onClick={onClick}
    >
      <CardHeader className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-sm font-medium truncate mb-1">
              {app.prompt.length > 30 ? `${app.prompt.substring(0, 30)}...` : app.prompt}
            </CardTitle>
            <CardDescription className="text-xs">
              {formatDate(app.created_at)}
            </CardDescription>
          </div>
          {getAppTypeIcon(app.type)}
        </div>
      </CardHeader>
    </Card>
  );
}
