
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Copy, Download } from "lucide-react";
import { GeneratedApp } from "@/types/generated-app";
import { formatDate, getAppTypeIcon, copyToClipboard, downloadAsFile } from "@/utils/app-utils";
import { useToast } from "@/components/ui/use-toast";

interface AppDetailProps {
  app: GeneratedApp;
}

export function AppDetail({ app }: AppDetailProps) {
  const { toast } = useToast();
  
  const handleCopy = () => {
    copyToClipboard(app.content);
    toast({
      title: "Copied to clipboard",
      description: "The code has been copied to your clipboard.",
    });
  };

  const handleDownload = () => {
    downloadAsFile(app.content, `app-${app.id}.txt`);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{app.prompt}</CardTitle>
        <CardDescription className="flex justify-between">
          <span>Generated on {formatDate(app.created_at)}</span>
          <span>{getAppTypeIcon(app.type)}</span>
        </CardDescription>
      </CardHeader>
      <Separator />
      <CardContent className="p-0">
        <Tabs defaultValue="preview">
          <TabsList className="mx-4 my-2">
            <TabsTrigger value="preview">Preview</TabsTrigger>
            <TabsTrigger value="code">Code</TabsTrigger>
          </TabsList>
          <TabsContent value="preview" className="p-4">
            <div className="bg-muted rounded-md p-4 overflow-hidden">
              <p>A preview of your application will appear here in the future.</p>
              <p className="text-muted-foreground text-sm mt-2">
                Currently, you can view and download the generated code.
              </p>
            </div>
          </TabsContent>
          <TabsContent value="code" className="p-4">
            <div className="bg-black rounded-md p-4 overflow-auto max-h-[400px]">
              <pre className="text-white text-sm font-mono whitespace-pre-wrap break-words">
                {app.content}
              </pre>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between p-4">
        <Button 
          variant="outline" 
          onClick={handleCopy}
          className="flex gap-2"
        >
          <Copy className="h-4 w-4" />
          Copy Code
        </Button>
        <Button 
          onClick={handleDownload}
          className="flex gap-2"
        >
          <Download className="h-4 w-4" />
          Download
        </Button>
      </CardFooter>
    </Card>
  );
}
