
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-neutral-dark text-white py-12">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Lovable</h3>
            <p className="text-neutral-light">
              Building the future of web development with AI.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Product</h4>
            <FooterLinks
              links={[
                { label: "Features", to: "/features" },
                { label: "Documentation", to: "/docs" },
                { label: "Pricing", to: "/pricing" },
                { label: "Updates", to: "/updates" },
              ]}
            />
          </div>
          <div>
            <h4 className="font-semibold mb-4">Company</h4>
            <FooterLinks
              links={[
                { label: "About", to: "/about" },
                { label: "Blog", to: "/blog" },
                { label: "Careers", to: "/careers" },
                { label: "Contact", to: "/contact" },
              ]}
            />
          </div>
          <div>
            <h4 className="font-semibold mb-4">Legal</h4>
            <FooterLinks
              links={[
                { label: "Privacy", to: "/privacy" },
                { label: "Terms", to: "/terms" },
                { label: "Security", to: "/security" },
              ]}
            />
          </div>
        </div>
        <div className="border-t border-white/10 mt-8 pt-8 text-center">
          <p className="text-neutral-light">© 2024 Lovable. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

type FooterLink = {
  label: string;
  to: string;
};

const FooterLinks = ({ links }: { links: FooterLink[] }) => (
  <ul className="space-y-2">
    {links.map((link) => (
      <li key={link.label}>
        <Link
          to={link.to}
          className="text-neutral-light hover:text-white transition-colors"
        >
          {link.label}
        </Link>
      </li>
    ))}
  </ul>
);

export default Footer;
