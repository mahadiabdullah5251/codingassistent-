
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Dashboard } from "@/components/Dashboard";
import { AppType } from "@/types/generated-app";

export function AppGenerator() {
  const [prompt, setPrompt] = useState('');
  const [type, setType] = useState<AppType>('fullstack');
  const [isLoading, setIsLoading] = useState(false);
  const [showDashboard, setShowDashboard] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Check if user is authenticated
      const { data: sessionData } = await supabase.auth.getSession();
      const userId = sessionData?.session?.user?.id;
      
      if (!userId) {
        toast({
          title: "Authentication Required",
          description: "Please sign in to generate and save applications.",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      // Call the edge function to generate code using Gemini API
      const { data, error } = await supabase.functions.invoke('generate-app', {
        body: { prompt, type, userId }
      });
      
      if (error) throw error;

      if (!data || !data.content) {
        throw new Error("No content was generated");
      }

      // Save the generated application to the database
      const { error: saveError } = await supabase
        .from('generated_apps')
        .insert({
          prompt,
          type,
          content: data.content,
          user_id: userId
        });

      if (saveError) throw saveError;

      toast({
        title: "Application Generated!",
        description: "Your code has been generated and saved successfully.",
      });

      setShowDashboard(true);
      console.log('Generated code:', data.content);

    } catch (error: any) {
      console.error('Error generating app:', error);
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate application code. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl mx-auto">
        <div className="space-y-2">
          <h2 className="text-2xl font-bold">Generate Your Application</h2>
          <p className="text-muted-foreground">
            Describe your application requirements and we'll generate the code for you using Google's Gemini AI.
          </p>
        </div>

        <div className="space-y-4">
          <Select
            value={type}
            onValueChange={(value: AppType) => setType(value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select application type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="frontend">Frontend Only</SelectItem>
              <SelectItem value="backend">Backend Only</SelectItem>
              <SelectItem value="fullstack">Full Stack</SelectItem>
            </SelectContent>
          </Select>

          <Textarea
            placeholder="Describe your application requirements..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="min-h-[200px]"
          />

          <Button type="submit" disabled={isLoading || !prompt}>
            {isLoading ? "Generating..." : "Generate Application"}
          </Button>
        </div>
      </form>

      {showDashboard && (
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Your Applications Dashboard</h2>
          <Dashboard />
        </div>
      )}
    </div>
  );
}
