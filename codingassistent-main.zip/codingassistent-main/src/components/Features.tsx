
import { Code, Sparkles, Zap } from "lucide-react";

const Features = () => {
  const features = [
    {
      icon: <Code className="w-8 h-8" />,
      title: "Code Generation",
      description: "Generate high-quality React code instantly with natural language commands.",
    },
    {
      icon: <Sparkles className="w-8 h-8" />,
      title: "Real-time Preview",
      description: "See your changes instantly with our live preview feature.",
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Quick Iterations",
      description: "Rapidly iterate and refine your designs with AI assistance.",
    },
  ];

  return (
    <section id="features" className="py-20 px-6 bg-neutral-light">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold text-center mb-16">Features</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="p-8 rounded-2xl bg-white shadow-sm hover-scale"
            >
              <div className="text-primary mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold mb-4">{feature.title}</h3>
              <p className="text-neutral">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
