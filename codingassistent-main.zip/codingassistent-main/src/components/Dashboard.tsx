
import React, { useState, useEffect } from 'react';
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";
import { GeneratedApp } from "@/types/generated-app";
import { AppCard } from "@/components/dashboard/AppCard";
import { AppDetail } from "@/components/dashboard/AppDetail";
import { EmptyState } from "@/components/dashboard/EmptyState";
import { LoadingState } from "@/components/dashboard/LoadingState";

export function Dashboard() {
  const [apps, setApps] = useState<GeneratedApp[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedApp, setSelectedApp] = useState<GeneratedApp | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const fetchApps = async () => {
      setLoading(true);
      
      try {
        const { data: session } = await supabase.auth.getSession();
        
        if (!session?.session?.user) {
          setApps([]);
          setLoading(false);
          return;
        }
        
        const { data, error } = await supabase
          .from('generated_apps')
          .select('*')
          .order('created_at', { ascending: false });
        
        if (error) throw error;
        
        // Cast the data to our GeneratedApp type
        const typedData = data as unknown as GeneratedApp[];
        setApps(typedData || []);
        
        if (typedData && typedData.length > 0) {
          setSelectedApp(typedData[0]);
        }
      } catch (error) {
        console.error('Error fetching apps:', error);
        toast({
          title: "Failed to load applications",
          description: "Could not retrieve your generated applications.",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchApps();

    const channel = supabase
      .channel('generated_apps_changes')
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'generated_apps' 
      }, (payload) => {
        const newApp = payload.new as unknown as GeneratedApp;
        setApps(prev => [newApp, ...prev]);
        setSelectedApp(newApp);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [toast]);

  if (loading) {
    return <LoadingState />;
  }

  if (apps.length === 0) {
    return <EmptyState />;
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-1/3 space-y-4">
          <h3 className="text-lg font-medium">Your Applications</h3>
          <div className="space-y-3 max-h-[400px] overflow-y-auto">
            {apps.map((app) => (
              <AppCard 
                key={app.id}
                app={app}
                isSelected={selectedApp?.id === app.id}
                onClick={() => setSelectedApp(app)}
              />
            ))}
          </div>
        </div>

        <div className="md:w-2/3">
          {selectedApp && <AppDetail app={selectedApp} />}
        </div>
      </div>
    </div>
  );
}
