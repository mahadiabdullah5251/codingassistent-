
export type AppType = "frontend" | "fullstack" | "backend";

export interface GeneratedApp {
  id: string;
  created_at: string;
  prompt: string;
  type: AppType;
  content: string;
  user_id: string;
}
